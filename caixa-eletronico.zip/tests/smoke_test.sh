#!/usr/bin/env bash
# Teste automatico: roda o caixa com entradas simuladas e confere as saidas.
# Uso: bash tests/smoke_test.sh ./caixa
set -u
BIN="$(cd "$(dirname "${1:-./caixa}")" && pwd)/$(basename "${1:-./caixa}")"
WORK="$(mktemp -d)"
cd "$WORK"
falhas=0

confere() {  # confere "descricao" "texto esperado" "saida"
  if grep -qF -- "$2" <<<"$3"; then echo "OK    - $1"
  else echo "FALHA - $1 (esperado: $2)"; falhas=$((falhas+1)); fi
}

# 1) login + saldo + saque de R$ 185 (1x100, 1x50, 1x20, 1x10, 1x5)
out=$(printf '1\n1001\n1234\n1\n2\n185\n0\n0\n' | "$BIN")
confere "login valido"            "Bem-vindo(a), Ana Paula Souza!" "$out"
confere "saldo inicial"           "Saldo: R\$ 1000.00" "$out"
confere "saque de 185 aprovado"   "Novo saldo: R\$ 815.00" "$out"

# 2) senha errada 3x bloqueia
out=$(printf '1\n1001\n0000\n0000\n0000\n0\n' | "$BIN")
confere "bloqueio apos 3 erros"   "Numero maximo de tentativas excedido" "$out"

# 3) saque nao multiplo de 5 e saldo insuficiente
out=$(printf '1\n1003\n1111\n2\n13\n2\n99995\n0\n0\n' | "$BIN")
confere "saque nao multiplo de 5" "multiplo de 5" "$out"
confere "saldo insuficiente"      "Saldo insuficiente" "$out"

# 4) deposito e transferencia persistem em arquivo
printf '1\n1002\n4321\n3\n100\n4\n1001\n50\n0\n0\n' | "$BIN" >/dev/null
[ -f extrato.txt ] && grep -q "TRANSF_ENV" extrato.txt \
  && echo "OK    - extrato.txt gravado" \
  || { echo "FALHA - extrato.txt"; falhas=$((falhas+1)); }

# 5) area administrativa: Quick Sort lista Bruno (maior saldo) primeiro
out=$(printf '2\n9999\n1\n0\n0\n' | "$BIN")
confere "relatorio de contas"     "CONTAS POR SALDO" "$out"

rm -rf "$WORK"
if [ "$falhas" -eq 0 ]; then echo "Todos os testes passaram."; else echo "$falhas teste(s) falharam."; exit 1; fi
