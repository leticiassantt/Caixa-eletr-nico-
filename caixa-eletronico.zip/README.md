# Caixa Eletrônico v2.0

Simulador de caixa eletrônico em **C**, executado no terminal. Projeto das aulas 10 a 15
(vetores/matrizes/strings, arquivos, funções e structs, ponteiros, Bubble Sort, recursividade e Quick Sort).

## Funcionalidades

- Login com número da conta e senha (máximo de 3 tentativas)
- Saldo, saque, depósito e transferência entre contas
- Saque com distribuição de cédulas por **recursividade** (R$ 100, 50, 20, 10 e 5), respeitando o estoque
- Extrato em ordem cronológica ou ordenado por valor (**Bubble Sort**)
- Área administrativa: relatório de contas por saldo (**Quick Sort**), estoque de cédulas, cadastro de contas e reabastecimento
- Persistência em arquivos: `contas.txt`, `extrato.txt`, `cedulas.txt` (criados na primeira execução)

## Como compilar e executar

```bash
gcc -Wall -Wextra -o caixa caixa_eletronico.c
./caixa
```

No Windows (MinGW): `gcc -o caixa.exe caixa_eletronico.c` e depois `caixa.exe`.

## Contas de teste

| Conta | Senha | Titular         |
|-------|-------|-----------------|
| 1001  | 1234  | Ana Paula Souza |
| 1002  | 4321  | Bruno Lima      |
| 1003  | 1111  | Carla Mendes    |

Senha da área administrativa: `9999`.

## Testes

```bash
bash tests/smoke_test.sh ./caixa
```

O workflow em `.github/workflows/ci-cd.yml` compila o código e roda esses testes a cada push e Pull Request.

## Conceitos aplicados

| Aula | Conceito | Onde aparece |
|------|----------|--------------|
| 10 | Matrizes e strings | matriz de cédulas `[2][5]`, `fgets`, `strcmp` |
| 11 | Arquivos | `fopen`, `fprintf`, `fscanf` em `.txt` |
| 12 | Structs e funções | `struct Conta`, `struct Transacao` |
| 13 | Ponteiros | `struct Conta *`, operador `->` |
| 14 | Bubble Sort | ordenação do extrato |
| 15 | Recursividade e Quick Sort | `distribuir_notas`, `quick_sort_contas` |
